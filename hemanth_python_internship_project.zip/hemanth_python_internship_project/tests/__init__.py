# Tests package initialization
